# Configuração do Firebase para Restaurante Sabor & Reserva

Este documento ajuda a criar o projeto Firebase e configurar Firestore, Authentication e as regras necessárias.

## 1. Criar projeto Firebase

1. Acesse https://console.firebase.google.com/.
2. Clique em "Adicionar projeto" e crie um novo projeto.
3. Aceite os termos e conclua a criação do projeto.

## 2. Ativar Authentication

1. No menu lateral, clique em `Authentication`.
2. Clique em `Começar`.
3. Em `Método de login`, ative a opção `Email/Senha`.
4. Salve.
5. Clique em `Usuários` e adicione um usuário administrador com email e senha.

## 3. Criar Firestore

1. No menu lateral, clique em `Firestore Database`.
2. Clique em `Criar banco de dados`.
3. Escolha `Iniciar no modo de teste` ou `Produção`.
4. Se escolher `Produção`, configure as regras após a criação.

## 4. Adicionar app Web

1. No menu `Configurações do projeto` (ícone de engrenagem), selecione `Configurações do projeto`.
2. Em `Seus apps`, clique em `</>` para criar um app Web.
3. Dê um nome ao app e confirme.
4. Copie o objeto de configuração exibido.

## 5. Atualizar `restaurant-site/firebase.js`

No arquivo `restaurant-site/firebase.js`, substitua o objeto `firebaseConfig` por suas credenciais reais:

```js
const firebaseConfig = {
  apiKey: "SEU_API_KEY",
  authDomain: "SEU_PROJECT_ID.firebaseapp.com",
  projectId: "SEU_PROJECT_ID",
  storageBucket: "SEU_PROJECT_ID.appspot.com",
  messagingSenderId: "SEU_MESSAGING_SENDER_ID",
  appId: "SEU_APP_ID"
};
```

## 6. Regras do Firestore

Use o arquivo `restaurant-site/firebase.rules` para configurar as regras do Firestore. Ele permite que:

- qualquer utilizador crie pedidos e reservas
- apenas administradores autenticados leiam pedidos e reservas

### Regras recomendadas

```js
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /orders/{orderId} {
      allow create: if true;
      allow read, update, delete: if request.auth != null;
    }
    match /reservations/{reservationId} {
      allow create: if true;
      allow read, update, delete: if request.auth != null;
    }
  }
}
```

## 7. Testar localmente

1. Abra `restaurant-site/index.html` em um navegador moderno.
2. Faça uma reserva e, em seguida, verifique se o pedido aparece no painel admin após login.
3. Confirme também que o WhatsApp abre corretamente com a mensagem.

## 8. Publicar

Este site é estático e pode ser publicado com:

- GitHub Pages
- Netlify
- Vercel

Basta enviar a pasta `restaurant-site` para o serviço.
