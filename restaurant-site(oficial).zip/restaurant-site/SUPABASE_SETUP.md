# Configuração do Supabase para Restaurante Sabor & Reserva

Siga estes passos para usar o Supabase como backend do seu projeto.

## 1. Criar projeto no Supabase

1. Acesse https://app.supabase.com/
2. Faça login na sua conta Supabase.
3. Clique em `New project`.
4. Dê um nome ao projeto e escolha uma senha para o banco de dados.
5. Clique em `Create new project`.

## 2. Criar tabela `orders`

1. No menu lateral, clique em `Database` > `Table Editor`.
2. Clique em `New table`.
3. Nome da tabela: `orders`.
4. Adicione os campos:
   - `id` (tipo `bigint` ou `uuid`, chave primária automática)
   - `date` (tipo `text`)
   - `items` (tipo `jsonb`)
   - `total` (tipo `numeric`)
   - `note` (tipo `text`)
   - `created_at` (tipo `timestamp with time zone`, valor padrão `now()`)
5. Salve a tabela.

## 3. Criar tabela `reservations`

1. Clique em `New table` novamente.
2. Nome da tabela: `reservations`.
3. Adicione os campos:
   - `id` (tipo `bigint` ou `uuid`, chave primária automática)
   - `name` (tipo `text`)
   - `email` (tipo `text`)
   - `date` (tipo `text`)
   - `time` (tipo `text`)
   - `guests` (tipo `integer`)
   - `notes` (tipo `text`)
   - `created_at` (tipo `timestamp with time zone`, valor padrão `now()`)
4. Salve a tabela.

## 4. Configurar Authentication

1. No menu lateral, clique em `Authentication`.
2. Vá em `Settings` > `External OAuth Providers` se quiser login via Google.
3. Para email/senha, vá em `Users` e clique em `New user`.
4. Insira o email e senha do administrador.

## 5. Copiar credenciais do Supabase

1. No menu lateral, clique em `Settings` > `API`.
2. Copie a `Project URL`.
3. Copie a `anon public` key.

## 6. Atualizar `supabase.js`

No arquivo `restaurant-site/supabase.js`, substitua:

```js
const supabaseUrl = 'YOUR_SUPABASE_URL';
const supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';
```

pelos valores reais do Supabase.

## 7. Testar o site

1. Abra `restaurant-site/index.html` usando um servidor local.
2. Faça uma reserva.
3. Faça um pedido.
4. Faça login em `Área Admin` com o usuário criado.
5. Confirme se as reservas e pedidos aparecem no painel admin.

## 8. Publicar

Este projeto é estático e pode ser publicado em serviços como GitHub Pages, Netlify ou Vercel.

Basta enviar a pasta `restaurant-site` e manter `index.html` na raiz.
