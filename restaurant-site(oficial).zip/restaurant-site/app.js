import {
    supabaseConfigured,
    saveReservation,
    saveOrder,
    fetchRecentOrders,
    fetchRecentReservations,
    signInAdmin,
    logoutAdmin,
    onAuthChange
} from './supabase.js';

const RESTAURANT_WHATSAPP = '351917248077'; // Número do restaurante para mensagens WhatsApp
const whatsappBaseUrl = `https://wa.me/${RESTAURANT_WHATSAPP}`;

const dishes = [
    { id: 1, name: 'Risoto de Camarão', description: 'Arroz cremoso com camarões frescos e ervas.', price: 59.90 },
    { id: 2, name: 'Bife Acebolado', description: 'Bife suculento com molho de cebola caramelizada.', price: 42.50 },
    { id: 3, name: 'Salada Mediterrânea', description: 'Mix de folhas, queijo feta, tomate e azeitonas.', price: 28.00 },
    { id: 4, name: 'Pizza Margherita', description: 'Base crocante, molho de tomate, mussarela e manjericão.', price: 34.90 },
    { id: 5, name: 'Lasanha de Frango', description: 'Camadas de massa com recheio cremoso e gratinado.', price: 39.90 },
    { id: 6, name: 'Brownie com Sorvete', description: 'Sobremesa quente servida com sorvete e calda.', price: 19.50 }
];

const dishGrid = document.getElementById('dishGrid');
const reservationsList = document.getElementById('reservationsList');
const ordersList = document.getElementById('ordersList');
const cartItemsEl = document.getElementById('cartItems');
const cartTotalEl = document.getElementById('cartTotal');
const checkoutButton = document.getElementById('checkoutButton');
const reservationForm = document.getElementById('reservationForm');
const adminToggle = document.getElementById('adminToggle');
const adminLoginSection = document.getElementById('adminLoginSection');
const adminPanel = document.getElementById('adminPanel');
const adminLoginForm = document.getElementById('adminLoginForm');
const adminEmailInput = document.getElementById('adminEmail');
const adminPasswordInput = document.getElementById('adminPassword');
const adminStatusText = document.getElementById('adminStatusText');
const adminOrdersList = document.getElementById('adminOrdersList');
const adminReservationsList = document.getElementById('adminReservationsList');
const signOutButton = document.getElementById('signOutButton');

let cart = JSON.parse(localStorage.getItem('restaurantCart')) || [];
let reservations = JSON.parse(localStorage.getItem('restaurantReservations')) || [];
let orders = JSON.parse(localStorage.getItem('restaurantOrders')) || [];
let pendingOrder = null;

function formatCurrency(value) {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function renderDishes() {
    dishGrid.innerHTML = dishes.map(dish => `
        <article class="dish-card">
            <h3>${dish.name}</h3>
            <p>${dish.description}</p>
            <div class="price-tag">${formatCurrency(dish.price)}</div>
            <button type="button" onclick="addToCart(${dish.id})">Adicionar ao carrinho</button>
        </article>
    `).join('');
}

window.addToCart = addToCart;
window.removeFromCart = removeFromCart;

function saveState() {
    localStorage.setItem('restaurantCart', JSON.stringify(cart));
    localStorage.setItem('restaurantReservations', JSON.stringify(reservations));
    localStorage.setItem('restaurantOrders', JSON.stringify(orders));
}

function renderReservations() {
    if (reservations.length === 0) {
        reservationsList.innerHTML = '<p class="empty-state">Nenhuma reserva ainda.</p>';
        return;
    }
    reservationsList.innerHTML = reservations.map(item => `
        <div class="list-item">
            <strong>${item.name} - ${item.date} às ${item.time}</strong>
            <span>${item.guests} convidados • ${item.email}</span>
            <p>${item.notes || 'Sem observações.'}</p>
        </div>
    `).join('');
}

function renderOrders() {
    if (orders.length === 0) {
        ordersList.innerHTML = '<p class="empty-state">Nenhuma encomenda registrada.</p>';
        return;
    }
    ordersList.innerHTML = orders.map(order => `
        <div class="list-item">
            <strong>Pedido #${order.id} - ${order.date}</strong>
            <span>${order.items.length} item(s) • Total ${formatCurrency(order.total)}</span>
            <p>${order.note || 'Encomenda enviada via WhatsApp.'}</p>
        </div>
    `).join('');
}

function renderCart() {
    if (cart.length === 0) {
        cartItemsEl.innerHTML = '<p class="empty-state">Seu carrinho está vazio. Adicione pratos do menu.</p>';
        cartTotalEl.textContent = formatCurrency(0);
        checkoutButton.disabled = true;
        return;
    }

    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    cartItemsEl.innerHTML = cart.map(item => `
        <div class="cart-item">
            <div>
                <strong>${item.name}</strong>
                <span>${item.quantity} x ${formatCurrency(item.price)}</span>
            </div>
            <button type="button" onclick="removeFromCart(${item.id})">Remover</button>
        </div>
    `).join('');
    cartTotalEl.textContent = formatCurrency(total);
    checkoutButton.disabled = false;
}

function addToCart(dishId) {
    const dish = dishes.find(item => item.id === dishId);
    if (!dish) return;
    const existing = cart.find(item => item.id === dishId);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ ...dish, quantity: 1 });
    }
    saveState();
    renderCart();
    alert(`✅ "${dish.name}" adicionado ao carrinho.`);
}

function removeFromCart(dishId) {
    const removedItem = cart.find(item => item.id === dishId);
    cart = cart.filter(item => item.id !== dishId);
    saveState();
    renderCart();
    if (removedItem) {
        alert(`⚠️ "${removedItem.name}" removido do carrinho.`);
    }
}

function showAdminLogin() {
    adminLoginSection.classList.toggle('hidden');
    adminPanel.classList.add('hidden');
}

async function saveReservationBackend(reservation) {
    if (!supabaseConfigured) {
        console.warn('Reserva salva localmente (Supabase ainda não configurado).');
        alert('⚠️ Supabase não configurado. Reserva salva apenas localmente.');
        return false;
    }
    try {
        await saveReservation(reservation);
        return true;
    } catch (error) {
        console.error('Falha ao salvar reserva no Supabase:', error.message);
        alert('❌ Falha ao salvar reserva no Supabase: ' + error.message);
        return false;
    }
}

async function saveOrderBackend(order) {
    if (!supabaseConfigured) {
        console.warn('Pedido salvo localmente (Supabase ainda não configurado).');
        alert('⚠️ Supabase não configurado. Pedido guardado apenas localmente.');
        return false;
    }
    try {
        await saveOrder(order);
        return true;
    } catch (error) {
        console.error('Falha ao salvar pedido no Supabase:', error.message);
        alert('❌ Falha ao salvar pedido no Supabase: ' + error.message);
        return false;
    }
}

function generateWhatsAppMessage(cartItems, total) {
    const items = cartItems.map(item => `- ${item.quantity}x ${item.name} (${formatCurrency(item.price)})`).join('\n');
    return `Olá, gostaria de fazer um pedido:%0A${items}%0A%0ATotal: ${formatCurrency(total)}%0A%0ANome:%0ATelefone:%0AObservações:`;
}

async function checkoutOrder() {
    if (cart.length === 0) {
        alert('Adicione produtos ao carrinho antes de finalizar o pedido.');
        return;
    }

    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const order = {
        id: Date.now(),
        date: new Date().toLocaleString('pt-BR'),
        items: [...cart],
        total,
        note: 'Pedido enviado por WhatsApp'
    };

    const backendSaved = await saveOrderBackend(order);
    orders.unshift(order);
    saveState();
    renderOrders();
    cart = [];
    saveState();
    renderCart();

    if (backendSaved) {
        alert('✅ Pedido preparado! Você será redirecionado para o WhatsApp.');
    } else {
        alert('⚠️ Pedido enviado para WhatsApp, mas não foi possível salvar no Supabase. Verifique as políticas RLS.');
    }
    const whatsappUrl = `${whatsappBaseUrl}?text=${generateWhatsAppMessage(order.items, total)}`;
    window.open(whatsappUrl, '_blank');
}

reservationForm.addEventListener('submit', async event => {
    event.preventDefault();

    const name = document.getElementById('resName').value.trim();
    const email = document.getElementById('resEmail').value.trim();
    const date = document.getElementById('resDate').value;
    const time = document.getElementById('resTime').value;
    const guests = document.getElementById('resGuests').value;
    const notes = document.getElementById('resNotes').value.trim();

    const reservation = {
        id: Date.now(),
        name,
        email,
        date,
        time,
        guests,
        notes
    };

    reservations.unshift(reservation);
    saveState();
    renderReservations();
    reservationForm.reset();
    await saveReservationBackend(reservation);
    alert('✅ Reserva efetuada com sucesso!');
});

function renderAdminOrders(orderList) {
    if (!orderList || orderList.length === 0) {
        adminOrdersList.innerHTML = '<p class="empty-state">Sem pedidos registrados no painel.</p>';
        return;
    }
    adminOrdersList.innerHTML = orderList.map(order => `
        <div class="list-item">
            <strong>${order.id}</strong>
            <span>${order.items?.length || 0} item(s) • ${formatCurrency(order.total || 0)}</span>
            <p>${order.note || ''}</p>
        </div>
    `).join('');
}

function renderAdminReservations(reservationList) {
    if (!reservationList || reservationList.length === 0) {
        adminReservationsList.innerHTML = '<p class="empty-state">Sem reservas registradas no painel.</p>';
        return;
    }
    adminReservationsList.innerHTML = reservationList.map(item => `
        <div class="list-item">
            <strong>${item.name} - ${item.date} às ${item.time}</strong>
            <span>${item.guests} convidados • ${item.email}</span>
            <p>${item.notes || 'Sem observações.'}</p>
        </div>
    `).join('');
}

async function loadAdminData() {
    if (!supabaseConfigured) {
        adminStatusText.textContent = 'Supabase não configurado. Atualize supabase.js com suas credenciais.';
        renderAdminOrders([]);
        renderAdminReservations([]);
        return;
    }

    try {
        adminStatusText.textContent = 'Carregando dados...';
        const [ordersSnapshot, reservationsSnapshot] = await Promise.all([
            fetchRecentOrders(),
            fetchRecentReservations()
        ]);
        renderAdminOrders(ordersSnapshot);
        renderAdminReservations(reservationsSnapshot);
        adminStatusText.textContent = 'Painel sincronizado com Supabase.';
    } catch (error) {
        adminStatusText.textContent = 'Não foi possível carregar os dados do Supabase.';
        console.warn('Falha ao ler dados do Supabase:', error.message);
    }
}

function showAdminPanel() {
    adminLoginSection.classList.add('hidden');
    adminPanel.classList.remove('hidden');
    loadAdminData();
}

function hideAdminPanel() {
    adminPanel.classList.add('hidden');
    adminLoginSection.classList.remove('hidden');
}

adminToggle.addEventListener('click', () => {
    showAdminLogin();
});

adminLoginForm.addEventListener('submit', async event => {
    event.preventDefault();
    const email = adminEmailInput.value.trim();
    const password = adminPasswordInput.value.trim();

    if (!email || !password) {
        alert('Insira suas credenciais de administrador.');
        return;
    }

    if (!supabaseConfigured) {
        alert('Supabase não configurado. Atualize supabase.js com as suas credenciais.');
        return;
    }

    try {
        await signInAdmin(email, password);
        adminEmailInput.value = '';
        adminPasswordInput.value = '';
        showAdminPanel();
        alert('✅ Login do administrador efetuado com sucesso!');
    } catch (error) {
        alert('❌ Falha no login: ' + error.message);
    }
});

signOutButton.addEventListener('click', async () => {
    if (!supabaseConfigured) {
        hideAdminPanel();
        return;
    }
    try {
        await logoutAdmin();
        hideAdminPanel();
        alert('✅ Administrador desconectado com sucesso.');
    } catch (error) {
        console.warn('Falha ao sair:', error.message);
        alert('❌ Falha ao sair.');
    }
});

onAuthChange(user => {
    if (user) {
        showAdminPanel();
    } else {
        hideAdminPanel();
    }
});

checkoutButton.addEventListener('click', checkoutOrder);

window.addEventListener('load', () => {
    renderDishes();
    renderCart();
    renderReservations();
    renderOrders();
});
